# OTIF Dashboard – Patch WMS Bridge

Este parche hace que el reporte OTIF tome datos desde *account.move* (WMS) sin romper históricos:

- **Fecha recibido** ahora usa `account.move.fecha_recibido` (fallback a `stock.picking.date_done`).
- **Descripción novedad** (`otif_novelty_desc`) y **Novedad** se llenan desde `account.move.novelty_id` / `account.move.description` si están vacías.
- **Estado mostrado** en la vista usa `otif_custom_state` (derivado de `account.move.custom_state`).
- Se agregan **Factura** (`otif_invoice_id`) y **Factura(s)** (`otif_invoice_numbers`) al lado de *Transferencia*.

## Archivos modificados
- `otif_dashboard/models/stock_picking_otif.py`
- `otif_dashboard/views/stock_picking_otif_views.xml`

## Cómo instalar
1. Haga backup de su módulo actual.
2. Reemplace los archivos por los de esta carpeta.
3. Actualice el módulo:
   ```
   odoo -u otif_dashboard
   ```
   o desde Apps, *Upgrade*.

> No se tocan campos nativos (`state`); todo es no intrusivo.
