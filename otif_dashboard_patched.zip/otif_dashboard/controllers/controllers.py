# -*- coding: utf-8 -*-
# from odoo import http


# class OtifDashboard(http.Controller):
#     @http.route('/otif_dashboard/otif_dashboard/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/otif_dashboard/otif_dashboard/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('otif_dashboard.listing', {
#             'root': '/otif_dashboard/otif_dashboard',
#             'objects': http.request.env['otif_dashboard.otif_dashboard'].search([]),
#         })

#     @http.route('/otif_dashboard/otif_dashboard/objects/<model("otif_dashboard.otif_dashboard"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('otif_dashboard.object', {
#             'object': obj
#         })
