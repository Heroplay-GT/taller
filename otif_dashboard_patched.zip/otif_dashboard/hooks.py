# -*- coding: utf-8 -*-
import logging
from datetime import datetime
from odoo import api, SUPERUSER_ID

_logger = logging.getLogger(__name__)

# Fecha límite para procesamiento (solo desde junio 2025)
JUN_2025 = datetime(2025, 6, 1)

# util para escribir también en ir.logging (Ajustes -> Técnico -> Registros)
def _log_to_ir(env, level, msg):
    env['ir.logging'].create({
        'name': 'otif_dashboard',
        'type': 'server',
        'dbname': env.cr.dbname,
        'level': level.upper(),
        'message': msg,
        'path': 'otif_dashboard.hooks',
        'func': 'post_init_check',
        'line': 0,
    })

def post_init_check(cr, registry):
    env = registry['env'](cr.dbname)  # Odoo 14: forma short; si prefieres, usa api.Environment(cr, SUPERUSER_ID, {})
    # fallback seguro:
    from odoo import api, SUPERUSER_ID
    env = api.Environment(cr, SUPERUSER_ID, {})

    def ok(x): return f"✅ {x}"
    def bad(x): return f"❌ {x}"

    try:
        _logger.debug("Iniciando post_init_check OTIF…")

        # 1) model: otif.compute.wizard
        wizard_exists = 'otif.compute.wizard' in env
        _logger.debug("Modelo wizard existe: %s", wizard_exists)
        _log_to_ir(env, 'info', (ok if wizard_exists else bad)("Modelo 'otif.compute.wizard'"))

        # 2) modelo account.move y campos críticos
        am = env['ir.model']._get('account.move')
        _log_to_ir(env, 'info', ok("Modelo 'account.move' disponible"))

        def has_field(model, fname):
            return fname in model._fields

        am_model = env['account.move']
        campos = ['otif_city_move', 'otif_status_move', 'otif_month_move',
                  'fecha_cargue', 'fecha_recibido', 'consecutivo_pedido']
        for c in campos:
            present = has_field(am_model, c)
            _logger.debug("Campo account.move.%s -> %s", c, present)
            _log_to_ir(env, 'info', (ok if present else bad)(f"Campo account.move.{c}"))

        # 3) vista de búsqueda (si existe)
        View = env['ir.ui.view']
        view_xmlid = 'otif_dashboard.view_account_move_search_otif'
        try:
            view = env.ref(view_xmlid)
            _log_to_ir(env, 'info', ok(f"Vista {view_xmlid} encontrada (id {view.id})"))
        except Exception as e:
            _log_to_ir(env, 'warning', bad(f"Vista {view_xmlid} NO encontrada: {e}"))

        # 4) probar un domain típico por fecha (solo log, no ejecuta acción)
        domain = "[('move_type','=','out_invoice'),('state','=','posted'),('consecutivo_pedido','!=',False)]"
        _log_to_ir(env, 'info', ok(f"Dominio base OK: {domain}"))

        # 5) Chequear si los campos fecha están realmente mapeados (del WMS)
        #    Si no existen, recomendamos usar el nombre real (ej: x_fecha_cargue)
        for c in ['fecha_cargue', 'fecha_recibido']:
            if not has_field(am_model, c):
                _log_to_ir(env, 'warning', bad(
                    f"El campo {c} no existe en account.move. Ajusta vistas/domains al nombre real de tu WMS (ej: x_{c})."))

        _log_to_ir(env, 'info', ok("post_init_check finalizado"))
        _logger.debug("post_init_check OTIF finalizado.")
    except Exception as e:
        _logger.exception("Fallo en post_init_check OTIF")
        _log_to_ir(env, 'error', bad(f"post_init_check Exception: {e}"))


def post_init_hook(cr, registry):
    """Hook de optimización que se ejecuta después de instalar/actualizar el módulo.
    Procesa solo registros recientes en lotes para evitar saturar memoria."""
    env = api.Environment(cr, SUPERUSER_ID, {'install_mode': True, 'module_installation': True})
    _logger.info("=== Iniciando post_init_hook optimizado OTIF ===")
    
    try:
        # Crear índices primero
        _create_indexes(env)
        
        # Procesar registros recientes en lotes (máximo 1000)
        _post_init_fill_recent(env)
        
        _logger.info("=== post_init_hook OTIF completado exitosamente ===")
        
    except Exception as e:
        _logger.exception("Error en post_init_hook OTIF: %s", e)
        raise


def _create_indexes(env):
    """Crea índices en campos críticos para optimizar consultas."""
    cr = env.cr
    _logger.info("Creando índices de optimización...")
    
    # Índices para campos que se usan en dominios y agrupaciones
    indexes = [
        ("idx_picking_scheduled_date", "stock_picking", "scheduled_date"),
        ("idx_picking_type_code", "stock_picking", "picking_type_code"),
        ("idx_picking_state", "stock_picking", "state"),
        ("idx_picking_partner", "stock_picking", "partner_id"),
        ("idx_picking_date_done", "stock_picking", "date_done"),
        # Campos custom OTIF
        ("idx_picking_otif_city", "stock_picking", "otif_city"),
        ("idx_picking_otif_status", "stock_picking", "otif_status"),
    ]
    
    for idx_name, table, column in indexes:
        try:
            cr.execute(f"CREATE INDEX IF NOT EXISTS {idx_name} ON {table} ({column})")
            _logger.info("✅ Índice creado: %s", idx_name)
        except Exception as e:
            _logger.warning("⚠️ Error creando índice %s: %s", idx_name, e)


def _post_init_fill_recent(env, chunk=1000):
    """Procesa solo 1000 registros recientes para evitar saturar memoria."""
    StockPicking = env['stock.picking']
    
    # Solo procesar registros recientes - LIMITADO A 1000 MÁXIMO
    domain = [
        ('picking_type_code', '=', 'outgoing'),
        ('scheduled_date', '>=', JUN_2025.strftime('%Y-%m-%d')),
    ]
    
    # Contar pero limitar a máximo 1000
    total_available = StockPicking.search_count(domain)
    max_to_process = min(1000, total_available)  # MÁXIMO 1000
    
    _logger.info("Disponibles: %s registros. Procesando solo: %s registros máximo", 
                total_available, max_to_process)
    
    if max_to_process == 0:
        _logger.info("No hay registros recientes para procesar")
        return
    
    # Procesar solo los primeros 1000
    picks = StockPicking.search(domain, order='id DESC', limit=max_to_process)
    
    _logger.info("Iniciando procesamiento de %s registros...", len(picks))
    
    # Procesar en un solo lote con norecompute
    with env.norecompute():
        # Solo asegurar que otif_counter está establecido
        picks_without_counter = picks.filtered(lambda p: not p.otif_counter)
        if picks_without_counter:
            picks_without_counter.write({'otif_counter': 1})
    
    # Aplicar cambios y liberar memoria
    env.flush_all()
    env.clear()
    env.cr.commit()
    
    _logger.info("✅ Procesamiento completado: %s registros (limitado a máximo 1000)", len(picks))
