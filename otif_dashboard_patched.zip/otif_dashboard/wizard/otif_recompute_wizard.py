# -*- coding: utf-8 -*-
import logging
import time
from datetime import datetime
from odoo import models, fields, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class OtifRecomputeWizard(models.TransientModel):
    _name = 'otif.recompute.wizard'
    _description = 'Recalcular OTIF en lotes'

    date_from = fields.Date(
        string='Fecha desde',
        required=True,
        default=lambda self: datetime(2025, 6, 1).date(),
        help='Fecha desde la cual recalcular los campos OTIF'
    )
    date_to = fields.Date(
        string='Fecha hasta',
        required=True,
        default=fields.Date.today,
        help='Fecha hasta la cual recalcular los campos OTIF'
    )
    chunk_size = fields.Integer(
        string='Tamaño de lote',
        default=1000,
        help='Número de registros a procesar por lote (para evitar saturar memoria)'
    )
    target_model = fields.Selection([
        ('stock.picking', 'Stock Picking'),
        ('account.move', 'Account Move'),
    ], string='Modelo a recalcular', default='stock.picking', required=True)
    
    # Campos de progreso
    state = fields.Selection([
        ('draft', 'Borrador'),
        ('running', 'Ejecutando'),
        ('done', 'Completado'),
        ('error', 'Error'),
    ], default='draft', readonly=True)
    
    progress = fields.Float(string='Progreso (%)', readonly=True)
    log_message = fields.Text(string='Log', readonly=True)

    def action_recompute(self):
        """Ejecuta el recálculo en lotes para evitar problemas de memoria."""
        self.ensure_one()
        
        if self.date_from > self.date_to:
            raise UserError(_('La fecha desde no puede ser mayor que la fecha hasta'))
        
        if self.chunk_size <= 0:
            raise UserError(_('El tamaño de lote debe ser mayor a 0'))
        
        try:
            self.state = 'running'
            self.progress = 0.0
            self.log_message = f"Iniciando recálculo para {self.target_model} desde {self.date_from} hasta {self.date_to}\n"
            
            if self.target_model == 'stock.picking':
                self._recompute_stock_picking()
            elif self.target_model == 'account.move':
                self._recompute_account_move()
            
            self.state = 'done'
            self.progress = 100.0
            self.log_message += "\n✅ Recálculo completado exitosamente"
            
        except Exception as e:
            self.state = 'error'
            self.log_message += f"\n❌ Error durante el recálculo: {str(e)}"
            _logger.exception("Error en wizard de recálculo OTIF")
            raise UserError(_('Error durante el recálculo: %s') % str(e))
        
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'otif.recompute.wizard',
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
        }

    def _recompute_stock_picking(self):
        """Recalcula campos OTIF para stock.picking en lotes."""
        StockPicking = self.env['stock.picking']
        
        # Dominio para filtrar por fechas
        domain = [
            ('picking_type_code', '=', 'outgoing'),
            ('scheduled_date', '>=', self.date_from),
            ('scheduled_date', '<=', self.date_to),
        ]
        
        total_count = StockPicking.search_count(domain)
        self.log_message += f"Total de registros a procesar: {total_count}\n"
        
        if total_count == 0:
            self.log_message += "No hay registros para procesar en el rango especificado\n"
            return
        
        offset = 0
        processed = 0
        
        while True:
            t0 = time.perf_counter()
            
            # Obtener lote de registros
            picks = StockPicking.search(domain, order='id', limit=self.chunk_size, offset=offset)
            if not picks:
                break
            
            # Procesar en lote con norecompute para optimizar
            with self.env.norecompute():
                # Forzar recálculo de campos específicos
                picks._compute_otif_fields()
                picks._compute_dimensions()
                picks._compute_references()
                picks._compute_dates()
                picks._compute_amount()
            
            # Aplicar cambios y liberar memoria
            self.env.cr.commit()
            self.env.clear()
            
            processed += len(picks)
            offset += self.chunk_size
            elapsed = time.perf_counter() - t0
            
            # Actualizar progreso
            self.progress = min(processed * 100.0 / total_count, 100.0)
            
            self.log_message += f"Procesados {processed}/{total_count} registros " \
                              f"({round(self.progress, 1)}%) - Lote: {len(picks)} en {elapsed:.2f}s\n"
            
            _logger.info("OTIF Wizard: procesados %s/%s registros (%s%%)", 
                        processed, total_count, round(self.progress, 1))

    def _recompute_account_move(self):
        """Recalcula campos OTIF para account.move en lotes."""
        AccountMove = self.env['account.move']
        
        # Dominio para filtrar por fechas
        domain = [
            ('move_type', '=', 'out_invoice'),
            ('state', '=', 'posted'),
            ('invoice_date', '>=', self.date_from),
            ('invoice_date', '<=', self.date_to),
        ]
        
        total_count = AccountMove.search_count(domain)
        self.log_message += f"Total de facturas a procesar: {total_count}\n"
        
        if total_count == 0:
            self.log_message += "No hay facturas para procesar en el rango especificado\n"
            return
        
        offset = 0
        processed = 0
        
        while True:
            t0 = time.perf_counter()
            
            # Obtener lote de registros
            moves = AccountMove.search(domain, order='id', limit=self.chunk_size, offset=offset)
            if not moves:
                break
            
            # Procesar en lote con norecompute para optimizar
            with self.env.norecompute():
                # Forzar recálculo de campos OTIF específicos del account.move
                # (aquí irían los métodos compute que tengas en account.move)
                pass
            
            # Aplicar cambios y liberar memoria
            self.env.cr.commit()
            self.env.clear()
            
            processed += len(moves)
            offset += self.chunk_size
            elapsed = time.perf_counter() - t0
            
            # Actualizar progreso
            self.progress = min(processed * 100.0 / total_count, 100.0)
            
            self.log_message += f"Procesadas {processed}/{total_count} facturas " \
                              f"({round(self.progress, 1)}%) - Lote: {len(moves)} en {elapsed:.2f}s\n"

    def action_reset(self):
        """Resetea el wizard para poder ejecutar de nuevo."""
        self.state = 'draft'
        self.progress = 0.0
        self.log_message = ''
        
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'otif.recompute.wizard',
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
        }