# -*- coding: utf-8 -*-
from odoo import api, fields, models

class OtifDiagWizard(models.TransientModel):
    _name = 'otif.diag.wizard'
    _description = 'Diagnóstico OTIF'

    report = fields.Text(readonly=True)

    def action_run(self):
        lines = []
        env = self.env
        def ok(x): return f"✅ {x}"
        def bad(x): return f"❌ {x}"

        # modelos
        lines.append(ok("Modelo account.move"))
        lines.append((ok if 'otif.compute.wizard' in env else bad)("Modelo otif.compute.wizard"))

        am = env['account.move']
        for c in ['otif_city_move','otif_status_move','otif_month_move','fecha_cargue','fecha_recibido','consecutivo_pedido']:
            lines.append((ok if c in am._fields else bad)(f"Campo account.move.{c}"))

        # vista
        try:
            view = env.ref('otif_dashboard.view_account_move_search_otif')
            lines.append(ok(f"Vista view_account_move_search_otif (id {view.id})"))
        except Exception as e:
            lines.append(bad(f"Vista view_account_move_search_otif NO existe: {e}"))

        # prueba de búsqueda (segura, sin fecha)
        try:
            env['account.move'].search([('move_type','=','out_invoice'),('state','=','posted')], limit=1)
            lines.append(ok("Search base sobre account.move ejecutó OK"))
        except Exception as e:
            lines.append(bad(f"Search base falló: {e}"))

        self.report = '\n'.join(lines)
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'otif.diag.wizard',
            'view_mode': 'form',
            'res_id': self.id,
            'target': 'new',
        }
