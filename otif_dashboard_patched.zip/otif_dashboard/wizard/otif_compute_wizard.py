# -*- coding: utf-8 -*-
from odoo import api, fields, models

class OtifComputeWizard(models.TransientModel):
    _name = 'otif.compute.wizard'
    _description = 'Recalcular OTIF'

    date_from = fields.Date(string='Desde', required=True, default=lambda self: self.env['ir.config_parameter'].sudo().get_param('otif_dashboard.min_date', '2025-06-01'))
    date_to = fields.Date(string='Hasta', required=True, default=fields.Date.context_today)
    compute_invoices = fields.Boolean(string='Calcular en Facturas', default=True)
    compute_pickings = fields.Boolean(string='Calcular en Picking', default=False)

    def action_compute(self):
        Param = self.env['ir.config_parameter'].sudo()
        sla_days = int(Param.get_param('otif_dashboard.sla_days', default='1') or '1')
        exclude_holidays = Param.get_param('otif_dashboard.exclude_holidays', default='True') in ('True', True, '1', 1)
        holidays = set(self.env['otif.holiday'].search([]).mapped('date')) if exclude_holidays else set()

        if self.compute_invoices:
            domain = [
                ('move_type', '=', 'out_invoice'),
                ('state', '=', 'posted'),
                ('consecutivo_pedido', '!=', False),
                ('fecha_cargue', '>=', self.date_from),
                ('fecha_cargue', '<=', self.date_to),
            ]
            moves = self.env['account.move'].search(domain)
            # Batch compute
            for batch in [moves[i:i+500] for i in range(0, len(moves), 500)]:
                batch._otif_compute_for_batch(holidays=holidays, sla_days=sla_days)

        if self.compute_pickings:
            # Opcional: invoca un helper similar en stock_picking_otif para pickings
            pick_domain = [
                ('picking_type_code', '=', 'outgoing'),
                ('state', 'in', ['done','cancel','assigned']),
                ('scheduled_date', '>=', self.date_from),
                ('scheduled_date', '<=', self.date_to),
            ]
            if hasattr(self.env['stock.picking'], '_otif_compute_for_batch'):
                picks = self.env['stock.picking'].search(pick_domain)
                for batch in [picks[i:i+500] for i in range(0, len(picks), 500)]:
                    batch._otif_compute_for_batch(holidays=holidays, sla_days=sla_days)

        return {'type': 'ir.actions.act_window_close'}
