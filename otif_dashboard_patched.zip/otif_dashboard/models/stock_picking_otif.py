# -*- coding: utf-8 -*-
from datetime import timedelta
import logging
import time
from odoo import api, fields, models, tools

_logger = logging.getLogger(__name__)

class StockPicking(models.Model):
    _inherit = 'stock.picking'

    # ==== Campos de reporte base ====
    otif_days_diff = fields.Float(
        string='Diferencia de días',
        compute='_compute_otif_fields',
        store=True,
        group_operator='avg',
        help='Diferencia en días naturales entre fecha recibido y fecha de cargue/transferencia.'
    )
    otif_business_days = fields.Integer(
        string='Sin domingos y festivos',
        compute='_compute_otif_fields',
        store=True,
        group_operator='avg',
        help='Cuenta de días hábiles inclusiva (incluye día de cargue), excluyendo domingos y festivos configurados.'
    )
    otif_in_full = fields.Boolean(
        string='IN FULL',
        compute='_compute_otif_fields',
        store=True,
        help='Entrega completa (qty_done == requerida).'
    )
    otif_is_late = fields.Boolean(
        string='Tarde',
        compute='_compute_otif_fields',
        store=True,
    )
    otif_status = fields.Selection([
        ('planned', 'Programado'),
        ('otif', 'OTIF (a tiempo y completo)'),
        ('late', 'Entregado tarde'),
        ('partial', 'Entrega parcial'),
        ('cancel', 'Cancelado'),
        ('other', 'Otro'),
    ], string='Estado OTIF', compute='_compute_otif_fields', store=True, index=True)
    
    # Contador técnico para usar como medida en pivot/graph
    otif_counter = fields.Integer(
        string='OTIF Counter',
        compute='_compute_otif_counter',
        store=True,
        index=True,
        help='Campo contador para usar en reportes pivot/graph'
    )

    otif_label = fields.Char(string='OTIF Label', compute='_compute_otif_fields', store=True,
                             help='Etiqueta tipo Excel: Entregado-0 / Entregado+N / Entrega Parcial / Programado')

    # Novedades (intenta mapear desde campos personalizados si existen)
    otif_novelty = fields.Char(string='Novedad', compute='_compute_otif_fields', store=True)
    otif_novelty_desc = fields.Char(string='Descripción Novedad', compute='_compute_otif_fields', store=True)

    # ==== Dimensiones para consolidados ====
    otif_city = fields.Char(string='Ciudad', compute='_compute_dimensions', store=True, index=True)
    otif_state_id = fields.Many2one('res.country.state', string='Departamento', compute='_compute_dimensions', store=True, index=True)
    otif_month = fields.Date(string='Mes (fecha recibida, primer día)', compute='_compute_dimensions', store=True, index=True,
                             help='Mes de la entrega (redondeado al primer día del mes) para facilitar pivots por mes.')
    
    # Bodega / Ciudad desde el tipo de operación
    warehouse_id = fields.Many2one(
        'stock.warehouse',
        string='Bodega/Ciudad',
        related='picking_type_id.warehouse_id',
        store=True,
        index=True,
    )

    # ==== NUEVOS CAMPOS OTIF SEGÚN REQUERIMIENTOS DEL JEFE ====
    # ON TIME (A tiempo) - Política de 24 horas
    otif_on_time = fields.Boolean(
        string='A tiempo',
        compute='_compute_otif_on_time',
        store=True, 
        index=True,
        help='Entrega a tiempo si se recibe dentro de 24h/día siguiente (máx 2 días hábiles)'
    )
    otif_business_days_new = fields.Integer(
        string='Días hábiles (nuevo)',
        compute='_compute_otif_on_time',
        store=True, 
        index=True,
        help='Días hábiles entre fecha transferencia y recibido (excluyendo domingos y festivos)'
    )

    # IN FULL (Completo) - Estados WMS
    otif_in_full_new = fields.Boolean(
        string='Completo (WMS)',
        compute='_compute_in_full',
        store=True, 
        index=True,
        help='Completo si todos los estados WMS están en estados válidos'
    )
    otif_in_full_detail = fields.Char(
        string='Detalle estados WMS',
        compute='_compute_in_full',
        store=True,
        help='Lista de estados custom_state encontrados en WMS'
    )

    # Contador robusto para medidas
    otif_counter_new = fields.Integer(
        string='Contador OTIF',
        compute='_compute_counter_new',
        store=True, 
        index=True,
        help='Campo contador para usar en reportes pivot/graph'
    )

    # Medidas para pivots (% como promedio de banderas)
    otif_score = fields.Float(string='Flag OTIF', compute='_compute_otif_fields', store=True, group_operator='avg')
    late_score = fields.Float(string='Flag Tarde', compute='_compute_otif_fields', store=True, group_operator='avg')
    partial_score = fields.Float(string='Flag Parcial', compute='_compute_otif_fields', store=True, group_operator='avg')
   

    # Columnas de referencia estilo Excel
    otif_transfer_number = fields.Char(string='Transferencia', compute='_compute_references', store=False)
    otif_order_sequence = fields.Char(string='Consecutivo del pedido', compute='_compute_references', store=False)
    otif_batch_number = fields.Char(string='Numero Cargue', compute='_compute_references', store=False)
    otif_partner_name = fields.Char(string='Asociado', compute='_compute_references', store=False)
    otif_invoice_numbers = fields.Char(string='Número (Factura)', compute='_compute_references', store=False)

    # Alias de fechas para vistas
    otif_transfer_date = fields.Datetime(string='Fecha transferencia', compute='_compute_dates', store=False)
    otif_load_date = fields.Datetime(string='Fecha de cargue', compute='_compute_dates', store=False)
    otif_received_date = fields.Datetime(string='Fecha de recibido', compute='_compute_dates', store=False)

    # Valor económico (opcional)
    otif_total_amount = fields.Monetary(string='Total (pedido)', currency_field='company_currency_id', compute='_compute_amount', store=False)
    company_currency_id = fields.Many2one('res.currency', related='company_id.currency_id', readonly=True)

    @api.depends()  # o cualquier campo estable para forzar el compute en existentes
    def _compute_otif_counter(self):
        for rec in self:
            rec.otif_counter = 1

    @api.depends('scheduled_date', 'date_done', 'state', 'move_lines.product_uom_qty', 'move_lines.quantity_done')
    def _compute_otif_fields(self):
        t0 = time.perf_counter()
        Param = self.env['ir.config_parameter'].sudo()
        sla_days = int(Param.get_param('otif_dashboard.sla_days', default='1') or '1')
        exclude_holidays = Param.get_param('otif_dashboard.exclude_holidays', default='True') in ('True', True, '1', 1)
        holidays = set(self.env['otif.holiday'].search([]).mapped('date')) if exclude_holidays else set()

        for picking in self:
            # Defaults
            picking.otif_days_diff = 0.0
            picking.otif_business_days = 0
            picking.otif_in_full = False
            picking.otif_is_late = False
            picking.otif_status = 'other'
            picking.otif_label = False
            picking.otif_novelty = False
            picking.otif_novelty_desc = False
            picking.otif_score = 0.0
            picking.late_score = 0.0
            picking.partial_score = 0.0

            if picking.state == 'cancel':
                picking.otif_status = 'cancel'
                picking.otif_label = 'Cancelado'
                continue

            # Fechas base
            start_dt = picking.scheduled_date or picking.create_date
            end_dt = picking.date_done
            # Preferir fecha_recibido desde account.move (WMS)
            try:
                moves = self.env['account.move'].search([('picking_id','=',picking.id)], order='fecha_recibido desc, id desc', limit=1)
                if moves and getattr(moves, 'fecha_recibido', False):
                    end_dt = fields.Datetime.to_datetime(moves.fecha_recibido)
            except Exception:
                pass

            if not start_dt:
                picking.otif_status = 'planned'
                picking.otif_label = 'Programado'
                continue

            
            # Completar novedad desde account.move.novelty_id / description si no está
            try:
                if not (picking.otif_novelty and picking.otif_novelty_desc):
                    _m = self.env['account.move'].search([('picking_id','=',picking.id)], order='fecha_recibido desc, id desc', limit=1)
                    if _m:
                        nov_name = getattr(_m.novelty_id, 'display_name', False) or getattr(_m.novelty_id, 'name', False)
                        desc = getattr(_m, 'description', False) or nov_name
                        picking.otif_novelty = picking.otif_novelty or nov_name
                        picking.otif_novelty_desc = picking.otif_novelty_desc or desc
            except Exception:
                pass
if not end_dt or picking.state != 'done':
                picking.otif_status = 'planned'
                picking.otif_label = 'Programado'
                continue

            # Diferencia de días naturales
            diff_days = (end_dt.date() - start_dt.date()).days
            picking.otif_days_diff = float(diff_days)

            # Días hábiles inclusivos (incluye inicio y fin)
            bdays = 0
            cur = start_dt.date()
            last = end_dt.date()
            one = timedelta(days=1)
            while cur <= last:
                if cur.weekday() != 6:  # 6 = domingo
                    if (cur not in holidays):
                        bdays += 1
                cur += one
            picking.otif_business_days = bdays

            # IN FULL
            total_required = 0.0
            total_done = 0.0
            for m in picking.move_lines:
                total_required += (m.product_uom_qty or 0.0)
                total_done += (m.quantity_done or 0.0)
            picking.otif_in_full = tools.float_compare(total_done, total_required, precision_digits=4) == 0

            # Novedades: intenta tomar de campos personalizados si existen
            nov = ''
            nov_desc = ''
            for fname in ['x_novedad', 'x_novedades', 'novedad']:
                if hasattr(picking, fname) and getattr(picking, fname):
                    nov = getattr(picking, fname)
                    break
            for fname in ['x_descripcion', 'x_novedad_desc', 'descripcion', 'x_observaciones']:
                if hasattr(picking, fname) and getattr(picking, fname):
                    nov_desc = getattr(picking, fname)
                    break
            picking.otif_novelty = nov or False
            picking.otif_novelty_desc = nov_desc or False

            # ¿OTIF o tarde?
            late = (bdays > sla_days)
            picking.otif_is_late = late

            if not picking.otif_in_full:
                picking.otif_status = 'partial'
                picking.otif_label = 'Entrega Parcial'
                picking.otif_novelty = picking.otif_novelty or 'Entrega Parcial'
                picking.partial_score = 1.0
            else:
                if late:
                    picking.otif_status = 'late'
                    picking.otif_label = 'Entregado+%s' % max(0, bdays - sla_days)
                    picking.otif_novelty = picking.otif_novelty or 'Entregado tarde'
                    picking.late_score = 1.0
                else:
                    picking.otif_status = 'otif'
                    picking.otif_label = 'Entregado-0'
                    picking.otif_score = 1.0
        
        # Log de performance
        elapsed = time.perf_counter() - t0
        _logger.info("OTIF _compute_otif_fields: %s registros en %.3fs", len(self), elapsed)

    @api.depends('partner_id', 'date_done')
    def _compute_dimensions(self):
        for p in self:
            # Ciudad / Departamento según dirección de entrega
            city = (p.partner_id.city or '').strip() if p.partner_id else ''
            p.otif_city = city
            p.otif_state_id = p.partner_id.state_id if p.partner_id else False
            # Mes redondeado al primer día (basado en fecha de recibido; si no, transferencia)
            base_date = (p.date_done or p.scheduled_date)
            if base_date:
                p.otif_month = base_date.replace(day=1).date()
            else:
                p.otif_month = False



    @api.depends('name', 'partner_id', 'origin', 'group_id', 'move_lines.sale_line_id.order_id.invoice_ids')
    def _compute_references(self):
        t0 = time.perf_counter()
        for p in self:
            p.otif_transfer_number = p.name or ''
            p.otif_partner_name = p.partner_id.display_name if p.partner_id else ''
            # Numero de cargue: batch enterprise o campo custom
            batch_name = False
            #if hasattr(p, 'batch_id') and p.batch_id:
                #batch_name = p.batch_id.name
            if hasattr(p, 'x_cargue_number') and p.x_cargue_number:
                batch_name = p.x_cargue_number
            p.otif_batch_number = batch_name or ''

            # Pedido
            sale = False
            if p.group_id and hasattr(p.group_id, 'sale_id') and p.group_id.sale_id:
                sale = p.group_id.sale_id
            else:
                sale = (p.move_lines.mapped('sale_line_id.order_id') or [False])[0]
            order_name = sale.name if sale else (p.origin or '')
            p.otif_order_sequence = order_name or ''

            # Facturas
            inv_names = []
            if sale and hasattr(sale, 'invoice_ids'):
                inv_names = [inv.name for inv in sale.invoice_ids if inv.move_type in ('out_invoice', 'out_refund')]
            p.otif_invoice_numbers = ', '.join(inv_names)
        
        # Log de performance
        elapsed = time.perf_counter() - t0
        _logger.info("OTIF _compute_references: %s registros en %.3fs", len(self), elapsed)

    @api.depends('scheduled_date', 'date_done')
    def _compute_dates(self):
        for p in self:
            p.otif_transfer_date = p.scheduled_date or p.create_date
            p.otif_load_date = p.scheduled_date or p.create_date
            p.otif_received_date = p.date_done

    # ==== NUEVOS MÉTODOS COMPUTE SEGÚN REQUERIMIENTOS DEL JEFE ====
    
    @api.model
    def _otif_debug_on(self):
        """Activa logs verbosos si:
        - En el contexto viene otif_debug=True, o
        - el sistema tiene el parámetro ir.config_parameter 'otif_dashboard.debug' = '1'
        """
        if self.env.context.get('otif_debug'):
            return True
        ICP = self.env['ir.config_parameter'].sudo()
        return ICP.get_param('otif_dashboard.debug', '0') in ('1', 'true', 'True')
    
    def _get_holidays_set(self):
        """Obtiene festivos configurados en otif.holiday"""
        holidays = set()
        try:
            if 'otif.holiday' in self.env:
                holiday_records = self.env['otif.holiday'].search([])
                for holiday in holiday_records:
                    if holiday.date:
                        holidays.add(holiday.date)
                if self._otif_debug_on():
                    _logger.debug("[OTIF] Festivos cargados: %s", sorted(map(str, holidays)))
        except Exception:
            if self._otif_debug_on():
                _logger.exception("[OTIF] Error obteniendo festivos")
        return holidays

    @staticmethod
    def _business_days_between(d_start, d_end, holidays=None):
        """Cuenta días hábiles entre d_start y d_end (incluyendo start y end).
        No laborables: domingos + festivos (sábados se consideran laborables)."""
        if not d_start or not d_end:
            return 0
        if d_end < d_start:
            return 0
        if holidays is None:
            holidays = set()
        total = 0
        cur = d_start
        while cur <= d_end:
            # weekday(): Lunes=0 ... Domingo=6
            if cur.weekday() != 6 and cur not in holidays:  # excluye domingos/festivos
                total += 1
            cur += timedelta(days=1)
        return total

    @api.depends('scheduled_date', 'date_done')
    def _compute_otif_on_time(self):
        """A tiempo si la entrega es dentro de 24h/día siguiente (máx 2 días hábiles)"""
        holidays = self._get_holidays_set()
        debug = self._otif_debug_on()
        for picking in self:
            try:
                d_prog = picking.scheduled_date.date() if picking.scheduled_date else None
                d_recv = picking.date_done.date() if picking.date_done else None

                if not d_prog or not d_recv:
                    picking.otif_business_days_new = 0
                    picking.otif_on_time = False
                    if debug:
                        _logger.info(
                            "[OTIF.ON_TIME] picking=%s name=%s → SIN FECHAS: scheduled=%s received=%s → on_time=False",
                            picking.id, picking.name, d_prog, d_recv
                        )
                    continue

                bd = self._business_days_between(d_prog, d_recv, holidays)
                picking.otif_business_days_new = bd
                # Política: máximo 2 días hábiles = a tiempo
                picking.otif_on_time = bd <= 2

                if debug:
                    _logger.info(
                        "[OTIF.ON_TIME] picking=%s name=%s wh=%s partner=%s "
                        "scheduled=%s received=%s business_days=%s on_time=%s",
                        picking.id, picking.name or 'Sin nombre',
                        picking.warehouse_id and picking.warehouse_id.display_name or 'Sin bodega',
                        picking.partner_id and picking.partner_id.display_name or 'Sin partner',
                        d_prog, d_recv, bd, picking.otif_on_time
                    )
            except Exception:
                _logger.exception("[OTIF.ON_TIME] Error en picking id=%s", picking.id)
                picking.otif_business_days_new = 0
                picking.otif_on_time = False

    @api.depends('name')
    def _compute_counter_new(self):
        """Contador robusto para medidas en pivot/graph"""
        debug = self._otif_debug_on()
        for rec in self:
            rec.otif_counter_new = 1
            if debug:
                _logger.debug("[OTIF.COUNTER] picking=%s set otif_counter_new=1", rec.id)

    @api.depends('name', 'partner_id')
    def _compute_in_full(self):
        """Verifica completitud según estados WMS custom_state"""
        debug = self._otif_debug_on()
        # Estados WMS que consideramos completos
        ok_states = {'completo', 'entregado', 'finalizado', 'cerrado'}
        # Estados que implican no completo
        not_ok_states = {'parcial', 'incompleto', 'pendiente', 'devuelto', 'anulado'}

        WMS_MODEL = 'wms.seguimiento.facturas'
        wms_model = self.env.get(WMS_MODEL)
        
        if debug:
            _logger.info("[OTIF.IN_FULL] Iniciando compute para %s registros. Modelo WMS disponible: %s", 
                        len(self), bool(wms_model))

        for picking in self:
            detail = []
            is_full = True

            try:
                if wms_model:
                    # Buscar por picking_id (ajustar si la relación es diferente)
                    domain = [('picking_id', '=', picking.id)]
                    if debug:
                        _logger.debug("[OTIF.IN_FULL] Buscando WMS: model=%s domain=%s", WMS_MODEL, domain)
                    
                    wms_lines = wms_model.search(domain)
                    states = set()
                    
                    for line in wms_lines:
                        if hasattr(line, 'custom_state') and line.custom_state:
                            st = line.custom_state.strip().lower()
                            if st:
                                states.add(st)
                    
                    detail = sorted(states)
                    
                    if not states:
                        is_full = False
                        reason = "sin_estados_wms"
                    elif any(s in not_ok_states for s in states):
                        is_full = False
                        reason = "tiene_estados_no_ok"
                    elif not states.issubset(ok_states):
                        is_full = False  
                        reason = "estados_desconocidos"
                    else:
                        reason = "todos_estados_ok"

                    if debug:
                        _logger.info(
                            "[OTIF.IN_FULL] picking=%s name=%s wms_count=%s states=%s in_full=%s reason=%s",
                            picking.id, picking.name or 'Sin nombre', len(wms_lines), detail, is_full, reason
                        )
                else:
                    is_full = False
                    if debug:
                        _logger.warning("[OTIF.IN_FULL] Modelo WMS no disponible: %s", WMS_MODEL)
                        
            except Exception:
                _logger.exception("[OTIF.IN_FULL] Error en picking id=%s", picking.id)
                is_full = False
                detail = []

            picking.otif_in_full_new = is_full
            picking.otif_in_full_detail = ', '.join(detail) if detail else False

    # ==== ACCIÓN MANUAL PARA DIAGNÓSTICO ====
    def action_otif_dump_log(self):
        """Acción de servidor: escribe un snapshot de campos clave en logs INFO."""
        debug_rows = []
        for p in self:
            row = {
                'id': p.id,
                'name': p.name,
                'scheduled_date': p.scheduled_date and p.scheduled_date.isoformat(),
                'date_done': p.date_done and p.date_done.isoformat(),
                'warehouse': p.warehouse_id and p.warehouse_id.display_name,
                'partner': p.partner_id and p.partner_id.display_name,
                'state': p.state,
                'otif_on_time': p.otif_on_time,
                'otif_business_days_new': p.otif_business_days_new,
                'otif_in_full_new': p.otif_in_full_new,
                'otif_in_full_detail': p.otif_in_full_detail,
                'otif_counter_new': p.otif_counter_new,
            }
            debug_rows.append(row)
        
        _logger.info("[OTIF.DUMP] === DIAGNÓSTICO MANUAL === %s registros: %s", len(debug_rows), debug_rows)
        
        # Notificación al usuario
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Depuración OTIF',
                'message': f'Se escribieron detalles de {len(debug_rows)} registros en el log del servidor. Revisa los logs para [OTIF.DUMP]',
                'sticky': False,
                'type': 'success',
            }
        }

    def _compute_amount(self):
        for p in self:
            amount = 0.0
            sale = False
            if p.group_id and hasattr(p.group_id, 'sale_id') and p.group_id.sale_id:
                sale = p.group_id.sale_id
            else:
                sale = (p.move_lines.mapped('sale_line_id.order_id') or [False])[0]
            if sale:
                amount = sale.amount_total
            p.otif_total_amount = amount

    # ==== Bridge WMS -> OTIF (sin romper históricos) ====
    otif_received_date = fields.Datetime(
        string='Fecha recibido',
        compute='_compute_otif_received_date',
        store=False,
    )
    otif_custom_state = fields.Char(
        string='Estado WMS',
        compute='_compute_otif_custom_state',
        store=False,
    )
    otif_invoice_id = fields.Many2one(
        'account.move',
        string='Factura',
        compute='_compute_otif_invoices',
        store=False,
    )
    otif_invoice_numbers = fields.Char(
        string='Factura(s)',
        compute='_compute_otif_invoices',
        store=False,
    )

    def _otif_get_moves(self):
        """Facturas (account.move) enlazadas por picking_id, ordenadas por fecha_recibido desc."""
        self.ensure_one()
        return self.env['account.move'].search(
            [('picking_id', '=', self.id)],
            order='fecha_recibido desc, invoice_date desc, id desc'
        )

    def _compute_otif_received_date(self):
        for p in self:
            moves = p._otif_get_moves() if hasattr(p, '_otif_get_moves') else self.env['account.move'].search([('picking_id','=',p.id)], order='fecha_recibido desc, id desc', limit=1)
            recv = moves[:1].fecha_recibido if moves else False
            p.otif_received_date = fields.Datetime.to_datetime(recv) if recv else p.date_done

    def _compute_otif_custom_state(self):
        for p in self:
            moves = p._otif_get_moves() if hasattr(p, '_otif_get_moves') else self.env['account.move'].search([('picking_id','=',p.id)], order='fecha_recibido desc, id desc')
            if moves:
                latest = moves[:1]
                states = [m.custom_state for m in moves if getattr(m, 'custom_state', False)]
                p.otif_custom_state = latest.custom_state or (', '.join(sorted(set(states))) if states else False)
            else:
                p.otif_custom_state = False

    def _compute_otif_invoices(self):
        for p in self:
            moves = p._otif_get_moves() if hasattr(p, '_otif_get_moves') else self.env['account.move'].search([('picking_id','=',p.id)], order='fecha_recibido desc, id desc')
            p.otif_invoice_id = moves[:1].id if moves else False
            names = [m.name for m in moves if getattr(m, 'name', False)]
            p.otif_invoice_numbers = ', '.join(names) if names else False

