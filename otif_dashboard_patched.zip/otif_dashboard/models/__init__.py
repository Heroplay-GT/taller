# -*- coding: utf-8 -*-

from . import account_move_otif
from . import res_config_settings
from . import otif_holiday
from . import stock_picking_otif