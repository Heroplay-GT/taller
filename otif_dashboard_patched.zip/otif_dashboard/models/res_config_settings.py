# -*- coding: utf-8 -*-
from odoo import api, fields, models

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    otif_sla_days = fields.Integer(
        string='SLA OTIF (días hábiles inclusivos)',
        default=1,
        config_parameter='otif_dashboard.sla_days',
    )
    otif_exclude_holidays = fields.Boolean(
        string='Excluir festivos (además de domingos)',
        default=True,
        config_parameter='otif_dashboard.exclude_holidays',
    )
    otif_min_date = fields.Char(
        string='Fecha mínima por defecto (YYYY-MM-DD)',
        default='2025-06-01',
        config_parameter='otif_dashboard.min_date',
        help='Fecha mínima para limitar búsquedas y recálculos por defecto. Formato: YYYY-MM-DD'
    )