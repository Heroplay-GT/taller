# -*- coding: utf-8 -*-
import logging
from datetime import timedelta
from odoo import api, fields, models

_logger = logging.getLogger(__name__)

class AccountMove(models.Model):
    _inherit = 'account.move'

    # ==== Campos OTIF en Factura (no se calculan automáticamente) ====
    otif_days_diff_move = fields.Float(string='Diferencia de días (Fac.)', index=True)
    otif_business_days_move = fields.Integer(string='Sin domingos y festivos (Fac.)', index=True)
    otif_in_full_move = fields.Boolean(string='IN FULL (Fac.)', index=True)
    otif_is_late_move = fields.Boolean(string='Tarde (Fac.)', index=True)
    otif_status_move = fields.Selection([
        ('planned', 'Programado'),
        ('otif', 'OTIF (a tiempo y completo)'),
        ('late', 'Entregado tarde'),
        ('partial', 'Entrega parcial'),
        ('cancel', 'Cancelado'),
        ('other', 'Otro'),
    ], string='Estado OTIF (Fac.)', index=True)
    otif_label_move = fields.Char(string='OTIF (Fac.)', index=True)
    otif_novelty_move = fields.Char(string='Novedad (Fac.)', index=True)

    # Dimensiones
    otif_city_move = fields.Char(string='Ciudad (Fac.)', index=True)
    otif_month_move = fields.Date(string='Mes (Fac.)', index=True)

    # Medidas (% promedio de banderas)
    otif_score_move = fields.Float(string='Flag OTIF (Fac.)', help='1 si OTIF, 0 en caso contrario', index=True)
    late_score_move = fields.Float(string='Flag Tarde (Fac.)', help='1 si tarde, 0 en caso contrario', index=True)
    partial_score_move = fields.Float(string='Flag Parcial (Fac.)', help='1 si parcial, 0 en caso contrario', index=True)

    # ==== Helpers de cálculo (llamados por wizard) ====
    def _otif_compute_for_batch(self, holidays, sla_days):
        _logger.info("Iniciando cálculo OTIF para %s facturas (SLA=%s)", len(self), sla_days)
        for m in self:
            _logger.debug("Procesando factura %s (state=%s)", m.name or m.id, m.state)

            # Defaults
            vals = {
                'otif_days_diff_move': 0.0,
                'otif_business_days_move': 0,
                'otif_in_full_move': False,
                'otif_is_late_move': False,
                'otif_status_move': 'other',
                'otif_label_move': False,
                'otif_novelty_move': False,
                'otif_city_move': (m.partner_id and (m.partner_id.city or '').strip()) or '',
                'otif_month_move': False,
                'otif_score_move': 0.0,
                'late_score_move': 0.0,
                'partial_score_move': 0.0,
            }

            if m.state == 'cancel':
                _logger.info("Factura %s cancelada → estado=cancel", m.name)
                vals.update({'otif_status_move': 'cancel', 'otif_label_move': 'Cancelado'})
                m.write(vals)
                continue

            start_dt = m.fecha_cargue or (m.picking_id and m.picking_id.scheduled_date) or False
            end_d = m.fecha_recibido or (m.picking_id and m.picking_id.date_done and m.picking_id.date_done.date()) or False

            if start_dt:
                base_date = (m.fecha_recibido or m.invoice_date or m.date) or start_dt.date()
                vals['otif_month_move'] = base_date.replace(day=1)
            else:
                _logger.debug("Factura %s → sin fecha de inicio → Programado", m.name)
                vals['otif_status_move'] = 'planned'
                vals['otif_label_move'] = 'Programado'
                m.write(vals)
                continue

            if not end_d:
                _logger.debug("Factura %s → sin fecha de fin → Programado", m.name)
                vals['otif_status_move'] = 'planned'
                vals['otif_label_move'] = 'Programado'
                m.write(vals)
                continue

            # Días naturales
            vals['otif_days_diff_move'] = float((end_d - start_dt.date()).days)
            _logger.debug("Factura %s → días naturales=%s", m.name, vals['otif_days_diff_move'])

            # Días hábiles inclusivo (sin domingos/feriados)
            bdays = 0
            cur = start_dt.date()
            last = end_d
            one = timedelta(days=1)
            while cur <= last:
                if cur.weekday() != 6 and (cur not in holidays):  # 6 = domingo
                    bdays += 1
                cur += one
            vals['otif_business_days_move'] = bdays
            _logger.debug("Factura %s → días hábiles=%s", m.name, bdays)

            # IN FULL
            in_full = False
            if m.picking_id:
                total_req = sum((mv.product_uom_qty or 0.0) for mv in m.picking_id.move_lines)
                total_done = sum((mv.quantity_done or 0.0) for mv in m.picking_id.move_lines)
                in_full = (abs(total_done - total_req) < 1e-4)
                _logger.debug("Factura %s → picking=%s, solicitado=%s, entregado=%s, in_full=%s",
                              m.name, m.picking_id.name, total_req, total_done, in_full)
            else:
                in_full = not bool(m.novedades)
                _logger.debug("Factura %s → sin picking, novedades=%s, in_full=%s", m.name, m.novedades, in_full)
            vals['otif_in_full_move'] = in_full

            # Etiquetas / estado
            late = (bdays > sla_days)
            vals['otif_is_late_move'] = late
            vals['otif_novelty_move'] = (m.novedades and m.novedades.name) or False

            if not in_full:
                vals.update({'otif_status_move': 'partial', 'otif_label_move': 'Entrega Parcial', 'partial_score_move': 1.0})
                _logger.info("Factura %s → resultado=Entrega Parcial", m.name)
            else:
                if late:
                    delay = max(0, bdays - sla_days)
                    vals.update({'otif_status_move': 'late', 'otif_label_move': 'Entregado+%s' % delay, 'late_score_move': 1.0})
                    _logger.info("Factura %s → resultado=Tarde (%s días)", m.name, delay)
                else:
                    vals.update({'otif_status_move': 'otif', 'otif_label_move': 'Entregado-0', 'otif_score_move': 1.0})
                    _logger.info("Factura %s → resultado=OTIF", m.name)

            m.write(vals)
