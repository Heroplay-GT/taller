# -*- coding: utf-8 -*-
from odoo import fields, models

class OtifHoliday(models.Model):
    _name = 'otif.holiday'
    _description = 'Festivo para cálculo OTIF'
    _order = 'date asc'

    name = fields.Char('Descripción', required=True)
    date = fields.Date('Fecha', required=True, index=True)
    active = fields.Boolean(default=True)
